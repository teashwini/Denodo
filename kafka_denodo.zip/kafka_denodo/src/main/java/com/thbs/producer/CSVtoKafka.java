package com.thbs.producer;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;
import org.json.simple.JSONValue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class CSVtoKafka {
    public static void main(String[] args) throws IOException {


    Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

    Producer<String, String> producer = new KafkaProducer<String, String>(props);

    CSVFormat csvFormat = CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase();

    Path path = Paths.get("C:\\Users\\tejashwini\\Documents\\CSV\\India1.csv");
    CSVParser csvParser = CSVParser.parse(path, StandardCharsets.UTF_8, csvFormat);
        JSONObject jsonObj = new JSONObject();
		for (CSVRecord csvRecord : csvParser) {

            String location = csvRecord.get("location");
            String date = csvRecord.get("date");
            String vaccine = csvRecord.get("vaccine");
            Integer total_vaccinations = Integer.parseInt(csvRecord.get("total_vaccinations"));
            Integer people_vaccinated = Integer.parseInt(csvRecord.get("people_vaccinated"));

            jsonObj.put("location", location);
            jsonObj.put("date", date);
            jsonObj.put("vaccine", vaccine);
            jsonObj.put("total_vaccinations",total_vaccinations);
            jsonObj.put("people_vaccinated", people_vaccinated);


            System.out.println(jsonObj);
            String data= JSONValue.toJSONString(jsonObj);
            producer.send(new ProducerRecord<String, String>("totalVaccineonDate", data));

    }

		producer.close();

}
}
