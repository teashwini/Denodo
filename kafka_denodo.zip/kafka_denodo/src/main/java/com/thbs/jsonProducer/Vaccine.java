package com.thbs.jsonProducer;

public class Vaccine {
	String location;
	String date,vaccine;
	int	total_vaccinations,	people_vaccinated;
	
	
	public Vaccine(String location, String date, String vaccine, int total_vaccinations, int people_vaccinated) {
		super();
		this.location = location;
		this.date = date;
		this.vaccine = vaccine;
		this.total_vaccinations = total_vaccinations;
		this.people_vaccinated = people_vaccinated;
	}
	

	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getVaccine() {
		return vaccine;
	}


	public void setVaccine(String vaccine) {
		this.vaccine = vaccine;
	}


	public int getTotal_vaccinations() {
		return total_vaccinations;
	}


	public void setTotal_vaccinations(int total_vaccinations) {
		this.total_vaccinations = total_vaccinations;
	}


	public int getPeople_vaccinated() {
		return people_vaccinated;
	}


	public void setPeople_vaccinated(int people_vaccinated) {
		this.people_vaccinated = people_vaccinated;
	}


	@Override
	public String toString() {
		return "Vaccine [location=" + location + ", date=" + date + ", vaccine=" + vaccine + ", total_vaccinations="
				+ total_vaccinations + ", people_vaccinated=" + people_vaccinated + "]";
	}

}
