package com.thbs.jsonProducer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;


public class CSVtoKafkaJSON {
	public static void main(String args[]) throws IOException {

		Properties properties = new Properties();
		String topic = "LatestVaccineData";

		properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
		properties.setProperty("acks", "all");
		properties.setProperty("group.id", "demo");

		Producer<String, Vaccine> producer = new KafkaProducer<String, Vaccine>(properties,
				new StringSerializer(), new KafkaJsonSerializer());
		
		
		CSVFormat csvFormat = CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase();

		Path path = Paths.get("C:\\Users\\tejashwini\\Documents\\CSV\\India1.csv");
		CSVParser csvParser = CSVParser.parse(path, StandardCharsets.UTF_8, csvFormat);
		for (CSVRecord csvRecord : csvParser) {

			String location = csvRecord.get("location");
			String date = csvRecord.get("date");
			String vaccine = csvRecord.get("vaccine");
			Integer total_vaccinations = Integer.parseInt(csvRecord.get("total_vaccinations"));
			Integer people_vaccinated = Integer.parseInt(csvRecord.get("people_vaccinated"));
			
			Vaccine Vacdata = new Vaccine(location,date,vaccine,total_vaccinations,people_vaccinated);
			ProducerRecord<String, Vaccine> producerRecord = new ProducerRecord<String, Vaccine>(topic, Vacdata);

			producer.send(producerRecord, new Callback() {

				@Override

				public void onCompletion(RecordMetadata metadata, Exception exception) {
				
					if (exception == null) {
						System.out.println("Successfully published Data!!");
						System.out.println(Vacdata);
					} else {
						exception.printStackTrace();
					}
				}
			});

			

		}
		producer.flush();
		producer.close();
			
		}
		
		
		

		

		

		


}
